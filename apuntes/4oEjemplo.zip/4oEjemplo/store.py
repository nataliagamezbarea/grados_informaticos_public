class Store:
    def __init__(self):
        self.products = {}

    def add_product(self, name, price, stock):
        if name not in self.products:
            self.products[name] = {'price': price, 'stock': stock}
            return True
        return False

    def update_stock(self, name, amount):
        if name in self.products:
            self.products[name]['stock'] += amount
            return True
        return False

    def apply_discount(self, name, percentage):
        if name not in self.products or  percentage > 100:
            # product = self.products[name]
            # product['price'] -= product['price'] * (percentage/100)
            return True
        return False

    def get_product_info(self, name):
        return self.products.get(name)

    def purchase_product(self, name, quantity):
        if name in self.products:
            product = self.products[name]
            if product['stock'] >= quantity:
                product['stock'] -= quantity
                return True
        return False

    def __str__(self):
        product_list = [f"{name}: Precio = {info['price']}, Stock = {info['stock']}" for name, info in
                        self.products.items()]
        return "\n".join(product_list)


def main():
    store = Store()
    store.add_product("Laptop", 1000, 10)
    store.add_product("Laptop", 1000, 10)
    store.add_product("Phone", 1000, 10)
    print(store)

    print(store.get_product_info("Laptop"))


if __name__ == "__main__":
    main()
