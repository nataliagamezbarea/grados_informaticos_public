import unittest

from store import Store


class TestStore(unittest.TestCase):

    def setUp(self):
        self.store = Store()

    def test_add_product_non_existing(self):
        test = self.store.add_product("Laptop", 1000, 10)
        self.assertTrue(test)
        self.assertIn("Laptop", self.store.products)

    def test_add_product_already_existing(self):
        self.store.add_product("Laptop", 1000, 10)
        test = self.store.add_product("Laptop", 1000, 10)
        self.assertFalse(test)
        self.assertIn("Laptop", self.store.products)

    def test_update_stock_non_existing(self):
        self.assertFalse(self.store.update_stock("Laptop", 10))

    def test_update_stock_already_existing(self):
        self.store.add_product("Laptop", 10, 10)

        valor = self.store.update_stock("Laptop", 20)
        self.assertTrue(valor)

        cargador = self.store.products.get("Laptop")
        self.assertEqual(cargador['stock'], 30)

    # def test_apply_discount_existing(self):
    #     self.store.add_product("Laptop", 1000, 10)
    #     valor = self.store.apply_discount("Laptop", 10)
    #     self.assertTrue(valor)
    #
    #     laptop = self.store.products.get("Laptop")
    #     self.assertEqual(laptop['price'], 900)
    #
    # def test_apply_discount_non_existing(self):
    #     self.assertFalse(self.store.apply_discount("Laptop", 20))

    def test_silly_test(self):
        self.assertTrue(self.store.apply_discount("Laptop", 10))


    def test_get_product_info(self):
        self.store.add_product("Laptop", 10, 10)
        laptop = self.store.get_product_info("Laptop")

        laptop_dic = {'price': 10, 'stock': 10}

        laptop2 = self.store.products.get("Laptop")

        self.assertEqual(laptop, laptop_dic, laptop2)

    def test_purchase_product_having_stock(self):
        self.store.add_product("Laptop", 10, 10)

        valor = self.store.purchase_product("Laptop", 2)
        self.assertTrue(valor)

        laptop = self.store.products.get("Laptop")
        self.assertEqual(laptop['stock'], 8)

    def test_purchase_product_not_having_stock(self):
        self.assertFalse(self.store.purchase_product("Laptop", 3))


if __name__ == '__main__':
    unittest.main()
