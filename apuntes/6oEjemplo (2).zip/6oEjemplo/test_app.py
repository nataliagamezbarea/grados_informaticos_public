import unittest

from app import app, db, User


class MyTestCase(unittest.TestCase):

    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLACHEMY_DATABASE_URI'] = 'sqlite:///:memory:'

        self.client = app.test_client()

        with app.app_context():
            db.create_all()

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def test_create_user(self):
        response = self.client.post("/users", json={"name": "juan"})
        self.assertEqual(response.status_code, 201)
        data = response.get_json()
        self.assertEqual(data['name'], "juan")

    def test_duplicate_user(self):
        response = self.client.post("/users", json={"telf": "manolo"})
        self.assertEqual(response.status_code, 400)
        data = response.get_json()
        self.assertEqual(data, {"error": "Nombre es requerido"})

    def test_get_all_users(self):
        with app.app_context():
            db.session.add(User(name="Ana"))
            db.session.add(User(name="Maria"))
            db.session.commit()

        response = self.client.get("/users")
        self.assertEqual(response.status_code, 200)

        data = response.get_json()
        self.assertEqual(len(data), 2)
        self.assertEqual(data[0]['name'], "Ana")
        self.assertEqual(data[1]['name'], "Maria")

    def test_get_user_by_id(self):
        response = self.client.post("/users", json={"name": "juan"})

        user_id = response.get_json()["id"]

        response_get = self.client.get(f"/users/{user_id}")
        self.assertEqual(response_get.status_code, 200)

        nombre = response_get.get_json()
        self.assertEqual(nombre['name'], "juan")

    def test_get_user_by_id_error(self):
        response_get = self.client.get(f"/users/999")
        self.assertEqual(response_get.status_code, 404)


if __name__ == '__main__':
    unittest.main()
