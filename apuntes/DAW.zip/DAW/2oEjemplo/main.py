from todo_list import TodoList


def main():
    miTodoList = TodoList()
    miTodoList.add_task("Estudiar EDD")
    miTodoList.add_task("Sobornar a José")
    miTodoList.add_task("Irse de cañas")

    miTodoList.mark_task_completed("Irse de cañas")
    print(miTodoList.get_pending_tasks())
    miTodoList.remove_task("Irse de cañas")
    print(miTodoList.get_pending_tasks())


if __name__ == "__main__":
    main()
