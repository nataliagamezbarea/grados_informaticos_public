import unittest
from todo_list import TodoList

class TestTodoList(unittest.TestCase):

    # setup -> preparar los test individualmente
    def setUp(self):
        self.todo_list = TodoList()

    # test_add_task() -> probar el método de suma
    def test_add_task(self):
        self.todo_list.add_task("Comprar pan")
        self.assertIn("Comprar pan", [task.title for task in self.todo_list.tasks])

    # test_remove_task() -> probar el método de borrado
    def test_remove_task(self):
        self.todo_list.add_task("Comprar pan")
        self.todo_list.remove_task("Comprar pan")
        self.assertNotIn("Comprar pan", [task.title for task in self.todo_list.tasks])

    # test_mark_task_completed() -> verificar que las tareas se completan
    def test_mark_task_completed(self):
        self.todo_list.add_task("Comprar pan")
        self.todo_list.mark_task_completed("Comprar pan")
        completed_task = [task for task in self.todo_list.tasks if task.title == "Comprar pan"][0]
        self.assertTrue(completed_task.completed)

    # test_get_pending_tasks() -> verificar el método que nos devuelve las tareas
    def test_get_pending_tasks(self):
        self.todo_list.add_task("Ir al gimnasio")
        self.todo_list.add_task("Desinstalar el lol")
        self.todo_list.mark_task_completed("Desinstalar el lol")
        pending_tasks = self.todo_list.get_pending_tasks()

        self.assertIn("Ir al gimnasio", pending_tasks)
        self.assertNotIn("Desinstalar el lol", pending_tasks)

if __name__ == '__main__':
    unittest.main()
