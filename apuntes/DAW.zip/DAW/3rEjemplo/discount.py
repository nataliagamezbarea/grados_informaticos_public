def calculate_discount(total, num_items, promo_code=None):
    # Calcularemos los descuentos en funcion de...
    discount = 0

    # Num items
    if num_items >= 5:
        discount += 10
    elif num_items == 4:
        discount += 5

    # Total
    if total > 100:
        discount += 15

    # Codigos promo
    if promo_code == "DESC20":
        discount += 20
    elif promo_code == "DESC10":
        discount += 10

    # Capar la promo
    if discount > 40:
        discount = 40

    # Aplicamos el descuento final
    final_price = total - (total * discount / 100)
    return final_price, discount


def main():
    # Probar todos los casos
    purchase1 = calculate_discount(120, 3, "DESC20")
    purchase2 = calculate_discount(80, 4, "DESC10")
    purchase3 = calculate_discount(50, 6)
    purchase4 = calculate_discount(150, 5)
    purchase5 = calculate_discount(200, 7, "DESC50")

    # Mostramos por pantalla
    print("Compra 1: Precio final = {:.2f}, Descuento {}%".format(purchase1[0], purchase1[1]) + "\n")
    print("Compra 2: Precio final = {:.2f}, Descuento {}%".format(purchase2[0], purchase2[1]) + "\n")
    print("Compra 3: Precio final = {:.2f}, Descuento {}%".format(purchase3[0], purchase3[1]) + "\n")
    print("Compra 4: Precio final = {:.2f}, Descuento {}%".format(purchase4[0], purchase4[1]) + "\n")
    print("Compra 5: Precio final = {:.2f}, Descuento {}%".format(purchase5[0], purchase5[1]) + "\n")


if __name__ == "__main__":
    main()
