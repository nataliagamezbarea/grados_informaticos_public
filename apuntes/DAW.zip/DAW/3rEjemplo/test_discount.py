import unittest


class TestDiscount(unittest.TestCase):

    # Caso 1: Total > 100, 3 productos, con código DESC20
    # Caso 2: Total < 100, 4 productos, con código DESC10
    # Caso 3: Total < 100, 6 productos, sin código de descuento
    # Caso 4: Total > 100, 5 productos, sin código de descuento
    # Caso 5: Total > 100, 7 productos, con código DESC50

if __name__ == '__main__':
    unittest.main()
