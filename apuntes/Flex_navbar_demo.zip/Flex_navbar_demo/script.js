// Use the following to include this JavaScript file 
// <script src="script.js"></script>
document.getElementById('toggleLayout').addEventListener('click', function () {
    const navbar = document.querySelector('.navbar');
    navbar.classList.toggle('horizontal');
    navbar.classList.toggle('vertical');
});