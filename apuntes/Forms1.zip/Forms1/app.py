from flask import Flask, render_template, request

app = Flask(__name__)


@app.route("/")
def index():
    title = "Bienvenido a Flask con Jinja2"
    description = "Esta página demuestra las características principales de Jinja2."
    return render_template("index.html", title=title, description=description)


@app.route('/form', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        return f"<h1>¡Gracias, {username}! </h1> <p> Te contactaremos en {email}. </p>"

    return render_template("form.html")


if __name__ == "__app__":
    app.run(debug=True)
